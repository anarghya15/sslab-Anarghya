#include<stdio.h>

int main(){
	for(;;){}
}
